using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BalaController : MonoBehaviour
{
    private Rigidbody2D myrigidbody2D;
    public float bulledSpeed = 10f;
    public GameManager gameManager;
    public int valor;

    // Start is called before the first frame update
    void Start()
    {
        myrigidbody2D = GetComponent<Rigidbody2D>();

    }

    // Update is called once per frame
    void Update()
    {
        myrigidbody2D.velocity = new Vector2(bulledSpeed, myrigidbody2D.velocity.y);
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("ItemBad"))
        {
            gameManager.SumarPuntos(valor);
            Destroy(collision.gameObject);
            
        }
    }
}
